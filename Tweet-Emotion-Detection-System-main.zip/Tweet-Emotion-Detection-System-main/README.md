# Tweet-Emotion-Detection-System



This project is created on the basis of a project related course on 'coursera'. 
It uses a tweet and its respective emotion dataset and predicts the emotion of dataset based on that.
